require("dotenv").config();

const express = require("express");
const app = express();
const port = process.env.PORT;

app.set("view engine", "ejs");
app.use(express.static("public"));

app.use(express.json());
app.use(express.urlencoded({ extended: true })); // body-parser 실행

const { MongoClient } = require("mongodb");
const uri = process.env.MONGODB_URL;
const client = new MongoClient(uri);

const fs = require("fs");
const uploadDir = "public/uploads/";

const multer = require("multer");
const path = require("path");
const e = require("express");

// 부모 디렉토리가 존재하지 않을 경우, 상위 디렉토리도 함께 생성할 수 있도록 설정
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir);

const getDB = async () => {
  await client.connect();
  return client.db("blog");
};

app.get("/", async (req, res) => {
  try {
    const db = await getDB();
    const posts = await db.collection("posts").find().toArray();
    // console.log(posts);
    res.render("index", { posts });
  } catch (e) {
    console.log(e);
  }
});

// 글작성페이지
app.get("/write", (req, res) => {
  res.render("write");
});

// Multer 설정
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, uploadDir); // 파일이 저장될 경로를 지정
  },
  filename: function (req, file, cb) {
    const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1e9);
    cb(
      null,
      file.fieldname + "-" + uniqueSuffix + path.extname(file.originalname)
    ); // 파일 이름 설정
  },
});

const upload = multer({ storage: storage });

app.post("/write", upload.single("postimg"), async (req, res) => {
  // console.log(req.body);
  const { title, content, createAtDate } = req.body;
  const postImg = req.file ? req.file.filename : null;
  // console.log(req.file);

  try {
    const db = await getDB();
    const result = await db.collection("counter").findOne({ name: "counter" });
    await db.collection("posts").insertOne({
      _id: result.totalPost + 1,
      title,
      content,
      createAtDate,
      postImgPath: postImg ? `uploads/${postImg}` : null,
    });
    await db
      .collection("counter")
      .updateOne({ name: "counter" }, { $inc: { totalPost: 1 } });
    res.redirect("/");
  } catch (error) {
    console.log(error);
  }
});

// 상세페이지
app.get("/detail/:id", async (req, res) => {
  const id = parseInt(req.params.id);

  try {
    const db = await getDB();
    const post = await db.collection("posts").findOne({ _id: id });
    res.render("detail", { post });
  } catch (error) {
    console.log(error);
  }
});

// 삭제기능
app.post("/delete", async (req, res) => {
  const id = parseInt(req.body.postNo);

  try {
    const db = await getDB();
    await db.collection("posts").deleteOne({ _id: id }); // _id : 몽고db의 키값, id : 요청한 id값
    res.redirect("/");
  } catch (error) {
    console.log(error);
  }
});

// 수정페이지
app.get("/edit/:id", async (req, res) => {
  const id = parseInt(req.params.id);

  try {
    const db = await getDB();
    const post = await db.collection("posts").findOne({ _id: id });
    res.render("edit", { post });
  } catch (error) {
    console.log(error);
  }
});

// 수정기능
app.post("/update", upload.single("postimg"), async (req, res) => {
  const id = parseInt(req.body.postNo);
  const { title, content, createAtDate } = req.body;
  const postImg = req.file ? req.file.filename : null;

  try {
    const db = await getDB();
    await db
      .collection("posts")
      .updateOne(
        { _id: parseInt(id) },
        { $set: { title, postImg, content, createAtDate } }
      );
    res.redirect("/");
  } catch (error) {
    console.log(error);
  }
});

app.listen(port, () => {
  console.log(`잘 돌아감 --- ${port}`);
});
